#!/usr/bin/env bash
# =============================================================================
#  configure.sh — Interactive First-Run Setup
#  entheogenstewardship.org/global-vision
#  Run this ONCE before setup.sh to configure your API keys and settings.
#  Your secrets are saved locally to .env and never leave your machine.
# =============================================================================

set -e

# ── Terminal colors & styles ──────────────────────────────────────────────────
RED='\033[0;31m';    GREEN='\033[0;32m';  YELLOW='\033[1;33m'
CYAN='\033[0;36m';   BLUE='\033[0;34m';   MAGENTA='\033[0;35m'
BOLD='\033[1m';      DIM='\033[2m';        NC='\033[0m'

# ── Helpers ───────────────────────────────────────────────────────────────────
print_header() {
  clear
  echo ""
  echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${BOLD}${CYAN}   🌍  Global Vision — Interactive Configuration Wizard${NC}"
  echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${DIM}   entheogenstewardship.org/global-vision${NC}"
  echo ""
}

section() {
  echo ""
  echo -e "${BOLD}${BLUE}┌─ $1 ${NC}"
  echo -e "${BLUE}└────────────────────────────────────────${NC}"
}

ask() {
  # ask <varname> <prompt> [default] [secret]
  local varname="$1"
  local prompt="$2"
  local default="$3"
  local secret="$4"

  local display_default=""
  [ -n "$default" ] && display_default=" ${DIM}(default: $default)${NC}"

  echo -ne "  ${CYAN}▸${NC} ${prompt}${display_default}: "

  local value
  if [ "$secret" = "secret" ]; then
    read -rs value          # silent — no echo
    echo ""                 # newline after hidden input
  else
    read -r value
  fi

  # Use default if blank
  [ -z "$value" ] && value="$default"

  # Export to caller scope
  printf -v "$varname" '%s' "$value"
}

ask_choice() {
  # ask_choice <varname> <prompt> <option1> <option2> ...
  local varname="$1"; shift
  local prompt="$1";  shift
  local options=("$@")

  echo -e "  ${CYAN}▸${NC} ${prompt}"
  for i in "${!options[@]}"; do
    echo -e "    ${DIM}[$((i+1))]${NC} ${options[$i]}"
  done
  echo -ne "  ${CYAN}  Choice [1-${#options[@]}]${NC}: "

  local choice
  read -r choice

  # Validate
  if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#options[@]}" ]; then
    printf -v "$varname" '%s' "${options[$((choice-1))]}"
  else
    printf -v "$varname" '%s' "${options[0]}"
  fi
}

confirm() {
  # confirm <prompt>  → returns 0 (yes) or 1 (no)
  echo -ne "  ${YELLOW}?${NC} $1 ${DIM}[y/N]${NC}: "
  local ans
  read -r ans
  [[ "$ans" =~ ^[Yy]$ ]]
}

success_msg() { echo -e "  ${GREEN}✓${NC}  $1"; }
warn_msg()    { echo -e "  ${YELLOW}!${NC}  $1"; }
info_msg()    { echo -e "  ${DIM}ℹ${NC}  ${DIM}$1${NC}"; }

# =============================================================================
#  INTRO SCREEN
# =============================================================================
print_header
echo -e "  This wizard will configure your 3D Globe installation."
echo -e "  You'll be asked for API keys and preferences."
echo -e "  ${BOLD}Secret values are hidden as you type and saved only to .env${NC}"
echo -e "  ${DIM}(which is gitignored and never uploaded to your server)${NC}"
echo ""
echo -ne "  Press ${BOLD}Enter${NC} to begin, or ${BOLD}Ctrl+C${NC} to cancel... "
read -r

# =============================================================================
#  SECTION 1 — Live Data API
# =============================================================================
print_header
section "Step 1 of 5 — Live Data API Provider"

echo ""
echo -e "  Your globe can display live data — weather, flights, seismic"
echo -e "  activity, ocean temperatures, or custom markers."
echo ""

ask_choice PROVIDER "Which live data provider are you using?" \
  "OpenWeatherMap  (weather layers)" \
  "AviationStack   (live flight tracking)" \
  "Mapbox          (maps, terrain, custom data)" \
  "Windy API       (wind / weather animation)" \
  "Custom / Other  (I'll enter my own URL)"

echo ""

# Set the default API URL based on provider choice
case "$PROVIDER" in
  "OpenWeatherMap"*)  DEFAULT_URL="https://api.openweathermap.org/data/2.5" ;;
  "AviationStack"*)   DEFAULT_URL="http://api.aviationstack.com/v1" ;;
  "Mapbox"*)          DEFAULT_URL="https://api.mapbox.com" ;;
  "Windy API"*)       DEFAULT_URL="https://api.windy.com/api/point-forecast/v2" ;;
  *)                  DEFAULT_URL="" ;;
esac

info_msg "Provider selected: $PROVIDER"
[ -n "$DEFAULT_URL" ] && info_msg "Default URL pre-filled: $DEFAULT_URL"
echo ""

ask LIVE_API_KEY  "Enter your API key" "" "secret"
ask LIVE_API_URL  "Enter your API base URL" "$DEFAULT_URL"

# Validate not empty
while [ -z "$LIVE_API_KEY" ]; do
  warn_msg "API key cannot be empty."
  ask LIVE_API_KEY "Enter your API key" "" "secret"
done

while [ -z "$LIVE_API_URL" ]; do
  warn_msg "API URL cannot be empty."
  ask LIVE_API_URL "Enter your API base URL" "$DEFAULT_URL"
done

success_msg "Live data API configured."

# =============================================================================
#  SECTION 2 — Mapbox Token (optional secondary)
# =============================================================================
print_header
section "Step 2 of 5 — Mapbox Token (Optional)"

echo ""
echo -e "  Mapbox provides high-quality tile overlays and GeoJSON support."
echo -e "  ${DIM}Skip this if you're not using Mapbox tile layers.${NC}"
echo ""

MAPBOX_TOKEN=""
if confirm "Do you have a Mapbox token to add?"; then
  echo ""
  ask MAPBOX_TOKEN "Enter your Mapbox public token" "" "secret"
  success_msg "Mapbox token saved."
else
  info_msg "Skipping Mapbox — you can add it later in .env"
fi

# =============================================================================
#  SECTION 3 — Hostinger FTP / Deploy (optional)
# =============================================================================
print_header
section "Step 3 of 5 — Hostinger Auto-Deploy (Optional)"

echo ""
echo -e "  The setup script can automatically upload your built files"
echo -e "  to Hostinger via FTP after each build."
echo -e "  ${DIM}Skip this to upload manually via hPanel File Manager.${NC}"
echo ""

FTP_HOST=""; FTP_USER=""; FTP_PASS=""

if confirm "Set up automatic FTP deploy to Hostinger?"; then
  echo ""
  info_msg "Find these in Hostinger hPanel → Hosting → FTP Accounts"
  echo ""
  ask FTP_HOST "FTP hostname" "ftp.entheogenstewardship.org"
  ask FTP_USER "FTP username" ""
  ask FTP_PASS "FTP password" "" "secret"

  while [ -z "$FTP_USER" ]; do
    warn_msg "FTP username cannot be empty."
    ask FTP_USER "FTP username" ""
  done

  success_msg "FTP deploy configured."
else
  info_msg "Skipping FTP — manual upload via hPanel File Manager."
fi

# =============================================================================
#  SECTION 4 — Globe Visual Defaults
# =============================================================================
print_header
section "Step 4 of 5 — Globe Default Appearance"

echo ""
echo -e "  Set the default visual settings for your globe."
echo -e "  ${DIM}These become the starting values for the Leva control panel.${NC}"
echo ""

ask LAND_COLOR   "Land color (hex)"            "#4a9e6b"
ask WATER_COLOR  "Water/ocean color (hex)"      "#1a4f7a"
ask ATMOS_COLOR  "Atmosphere glow color (hex)"  "#3a7bd5"

ask_choice SPIN_DEFAULT "Spin enabled on load?" \
  "true  (globe spins automatically)" \
  "false (user initiates spin)"
SPIN_DEFAULT=$(echo "$SPIN_DEFAULT" | awk '{print $1}')   # extract true/false

ask_choice PARTICLE_DEFAULT "Particle animation on load?" \
  "true  (particles animate upward)" \
  "false (particles static)"
PARTICLE_DEFAULT=$(echo "$PARTICLE_DEFAULT" | awk '{print $1}')

success_msg "Visual defaults saved."

# =============================================================================
#  SECTION 5 — Project Paths
# =============================================================================
print_header
section "Step 5 of 5 — Project Paths"

echo ""
echo -e "  Confirm where things will be installed."
echo ""

ask INSTALL_DIR  "Server install directory"       "${HOME}/public_html/global-vision"
ask PUBLIC_URL   "Public URL for the globe"        "https://entheogenstewardship.org/global-vision"

success_msg "Paths configured."

# =============================================================================
#  REVIEW SCREEN
# =============================================================================
print_header
section "Review Your Configuration"

echo ""
echo -e "  ${BOLD}Live Data Provider:${NC}   $PROVIDER"
echo -e "  ${BOLD}API URL:${NC}              $LIVE_API_URL"
echo -e "  ${BOLD}API Key:${NC}              ${DIM}[hidden — $(echo -n "$LIVE_API_KEY" | wc -c) chars]${NC}"
echo -e "  ${BOLD}Mapbox Token:${NC}         $([ -n "$MAPBOX_TOKEN" ] && echo "${DIM}[set — $(echo -n "$MAPBOX_TOKEN" | wc -c) chars]${NC}" || echo "${DIM}not set${NC}")"
echo ""
echo -e "  ${BOLD}FTP Host:${NC}             $([ -n "$FTP_HOST" ] && echo "$FTP_HOST" || echo "${DIM}not configured${NC}")"
echo -e "  ${BOLD}FTP User:${NC}             $([ -n "$FTP_USER" ] && echo "$FTP_USER" || echo "${DIM}not configured${NC}")"
echo ""
echo -e "  ${BOLD}Land Color:${NC}           $LAND_COLOR"
echo -e "  ${BOLD}Water Color:${NC}          $WATER_COLOR"
echo -e "  ${BOLD}Atmosphere Color:${NC}     $ATMOS_COLOR"
echo -e "  ${BOLD}Spin on Load:${NC}         $SPIN_DEFAULT"
echo -e "  ${BOLD}Particle Anim:${NC}        $PARTICLE_DEFAULT"
echo ""
echo -e "  ${BOLD}Install Directory:${NC}    $INSTALL_DIR"
echo -e "  ${BOLD}Public URL:${NC}           $PUBLIC_URL"
echo ""

if ! confirm "Save this configuration and proceed?"; then
  echo ""
  warn_msg "Configuration cancelled. Nothing was saved."
  echo ""
  exit 0
fi

# =============================================================================
#  WRITE .env
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_PATH="${SCRIPT_DIR}/.env"

cat > "$ENV_PATH" << ENV
# =============================================================================
#  .env — Globe Configuration
#  Generated by configure.sh on $(date)
#  DO NOT commit this file to git. It is listed in .gitignore.
# =============================================================================

# ── Live Data API ─────────────────────────────────────────────────────────────
LIVE_DATA_PROVIDER=${PROVIDER}
LIVE_DATA_API_KEY=${LIVE_API_KEY}
LIVE_DATA_API_URL=${LIVE_API_URL}

# ── Mapbox (optional) ─────────────────────────────────────────────────────────
MAPBOX_TOKEN=${MAPBOX_TOKEN}

# ── Hostinger FTP Deploy (optional) ──────────────────────────────────────────
HOSTINGER_FTP_HOST=${FTP_HOST}
HOSTINGER_FTP_USER=${FTP_USER}
HOSTINGER_FTP_PASS=${FTP_PASS}

# ── Globe Visual Defaults ─────────────────────────────────────────────────────
GLOBE_LAND_COLOR=${LAND_COLOR}
GLOBE_WATER_COLOR=${WATER_COLOR}
GLOBE_ATMOS_COLOR=${ATMOS_COLOR}
GLOBE_SPIN_DEFAULT=${SPIN_DEFAULT}
GLOBE_PARTICLE_DEFAULT=${PARTICLE_DEFAULT}

# ── Project Paths ─────────────────────────────────────────────────────────────
INSTALL_DIR=${INSTALL_DIR}
PUBLIC_URL=${PUBLIC_URL}
ENV

chmod 600 "$ENV_PATH"    # owner read/write only — protect secrets

# =============================================================================
#  UPDATE globeStore defaults from .env values
# =============================================================================
STORE_PATH="${SCRIPT_DIR}/src/globeStore.ts"

if [ -f "$STORE_PATH" ]; then
  # Inject default colors from .env into the Zustand store
  sed -i "s|landColor:.*'#[0-9a-fA-F]*'|landColor:        '${LAND_COLOR}'|g"  "$STORE_PATH"
  sed -i "s|waterColor:.*'#[0-9a-fA-F]*'|waterColor:       '${WATER_COLOR}'|g" "$STORE_PATH"
  sed -i "s|spinEnabled:.*true\|false|spinEnabled:      ${SPIN_DEFAULT}|g"     "$STORE_PATH"
  sed -i "s|particleAnim:.*true\|false|particleAnim:     ${PARTICLE_DEFAULT}|g" "$STORE_PATH"
fi

# =============================================================================
#  WRITE src/config.ts with injected values
# =============================================================================
CONFIG_PATH="${SCRIPT_DIR}/src/config.ts"

cat > "$CONFIG_PATH" << CONFIG
// =============================================================
//  config.ts — Auto-generated by configure.sh on $(date)
//  DO NOT edit manually — re-run configure.sh to update
// =============================================================

export const CONFIG = {
  provider:      '${PROVIDER}',
  liveDataApiKey: '${LIVE_API_KEY}',
  liveDataApiUrl: '${LIVE_API_URL}',
  mapboxToken:    '${MAPBOX_TOKEN}',
  publicUrl:      '${PUBLIC_URL}',

  defaults: {
    landColor:    '${LAND_COLOR}',
    waterColor:   '${WATER_COLOR}',
    atmosColor:   '${ATMOS_COLOR}',
    spin:          ${SPIN_DEFAULT},
    particleAnim:  ${PARTICLE_DEFAULT},
  },
} as const
CONFIG

# =============================================================================
#  DONE
# =============================================================================
print_header

echo -e "  ${GREEN}${BOLD}✓  Configuration complete!${NC}"
echo ""
echo -e "  Files written:"
echo -e "  ${DIM}•${NC}  ${BOLD}.env${NC}            ${DIM}(chmod 600 — secrets protected)${NC}"
echo -e "  ${DIM}•${NC}  ${BOLD}src/config.ts${NC}   ${DIM}(injected into React build)${NC}"
echo ""
echo -e "  ${BOLD}Next step — run the main setup script:${NC}"
echo ""
echo -e "    ${CYAN}chmod +x setup.sh && ./setup.sh${NC}"
echo ""
echo -e "  ${DIM}To reconfigure at any time, just run:${NC}"
echo -e "    ${CYAN}./configure.sh${NC}"
echo ""
