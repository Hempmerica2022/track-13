// =============================================================================
//  Globe Point Cloud — Fragment Shader (GLSL ES 3.0 / WebGL 1+2 compatible)
//  Cross-platform: Chrome, Firefox, Safari, Edge, iOS, Android
// =============================================================================

precision mediump float;

// ── Uniforms ──────────────────────────────────────────────────────────────────
uniform float uGlowAmount;      // bloom intensity hint (0..2)
uniform float uGlowThreshold;   // minimum brightness to glow

// ── Varyings from vertex shader ───────────────────────────────────────────────
varying vec3  vColor;
varying float vElevation;
varying float vLand;
varying float vOpacity;

void main() {

  // ── 1. Soft circular point (WebGL gl_PointCoord gives 0..1 across the point)
  vec2  uv      = gl_PointCoord - vec2(0.5);
  float dist    = length(uv);

  // Hard-discard outside circle (no square points)
  if (dist > 0.5) discard;

  // Soft edge falloff — smooth disc
  float alpha   = smoothstep(0.5, 0.2, dist);

  // ── 2. Elevation-based brightness boost ────────────────────────────────────
  //  High elevation points are slightly brighter (simulates snow/peak glow)
  float brightness = 1.0 + vElevation * 0.4 * vLand;
  vec3  color      = vColor * brightness;

  // ── 3. Glow threshold mask ─────────────────────────────────────────────────
  //  Points above the threshold get a boosted luminance passed to bloom
  float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
  float glowMask  = smoothstep(uGlowThreshold, uGlowThreshold + 0.1, luminance);
  color           = color + color * glowMask * uGlowAmount * 0.3;

  // ── 4. Final color + opacity ───────────────────────────────────────────────
  gl_FragColor    = vec4(color, alpha * vOpacity);
}
