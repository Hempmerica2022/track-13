// =============================================================================
//  Atmosphere Glow — Vertex Shader
//  Renders a slightly enlarged sphere behind the globe as a soft halo
// =============================================================================

varying vec3 vNormal;
varying vec3 vViewDir;

void main() {
  vNormal     = normalize(normalMatrix * normal);
  vec4 mvPos  = modelViewMatrix * vec4(position, 1.0);
  vViewDir    = normalize(-mvPos.xyz);
  gl_Position = projectionMatrix * mvPos;
}
