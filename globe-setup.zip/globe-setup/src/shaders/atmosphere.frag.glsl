// =============================================================================
//  Atmosphere Glow — Fragment Shader
//  Fresnel-based rim glow — works identically on all WebGL devices
// =============================================================================

precision mediump float;

uniform vec3  uAtmosColor;    // e.g. soft blue #4488ff
uniform float uAtmosStrength; // 0..2

varying vec3 vNormal;
varying vec3 vViewDir;

void main() {
  // Fresnel: bright at grazing angles (rim), dark at center (facing camera)
  float fresnel   = 1.0 - max(dot(vNormal, vViewDir), 0.0);
  fresnel         = pow(fresnel, 3.5);                  // sharpen the rim

  float intensity = fresnel * uAtmosStrength;
  vec3  color     = uAtmosColor * intensity;

  gl_FragColor    = vec4(color, intensity * 0.6);
}
