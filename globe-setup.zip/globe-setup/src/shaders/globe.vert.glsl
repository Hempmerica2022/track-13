// =============================================================================
//  Globe Point Cloud — Vertex Shader (GLSL ES 3.0 / WebGL 1+2 compatible)
//  Cross-platform: Chrome, Firefox, Safari, Edge, iOS, Android
// =============================================================================

// ── Attributes (per-point data from Python pipeline) ─────────────────────────
attribute vec3  direction;      // unit sphere direction from lat/lon
attribute float elevation;      // normalized 0..1
attribute float land;           // 1.0 = land, 0.0 = river

// ── Uniforms (driven by Leva sliders via Zustand) ────────────────────────────
uniform float uTime;            // elapsed seconds
uniform float uElevationScale;  // exaggeration multiplier
uniform float uGlobeRadius;     // base sphere radius
uniform float uPointSize;       // base point size
uniform float uColorBlend;      // land vs water blend
uniform vec3  uLandColor;       // land color
uniform vec3  uWaterColor;      // river/water color
uniform float uParticleAnim;    // 0 = off, 1 = on
uniform float uAnimSpeed;       // animation speed

// ── Varyings (passed to fragment shader) ─────────────────────────────────────
varying vec3  vColor;
varying float vElevation;
varying float vLand;
varying float vOpacity;

// ── Pseudo-random hash (no texture needed — pure math) ────────────────────────
float hash(float n) {
  return fract(sin(n) * 43758.5453123);
}

// ── Smooth noise for wobble path ──────────────────────────────────────────────
float noise(float x) {
  float i = floor(x);
  float f = fract(x);
  float u = f * f * (3.0 - 2.0 * f); // smoothstep
  return mix(hash(i), hash(i + 1.0), u);
}

void main() {

  // ── 1. Particle animation: rise from slightly below target elevation ────────
  float seed        = hash(direction.x * 127.1 + direction.y * 311.7 + direction.z * 74.3);
  float animDelay   = seed;                            // staggered start 0..1
  float animPhase   = mod(uTime * uAnimSpeed + animDelay, 1.5); // loop
  float travelT     = clamp(animPhase / 1.0, 0.0, 1.0);
  float smoothT     = travelT * travelT * (3.0 - 2.0 * travelT); // smoothstep

  // Wobble along the path (secondary motion — tutorial's "wobble" effect)
  float wobbleSeed  = seed * 6.2831853;
  float wobble      = sin(uTime * 1.5 + wobbleSeed) * 0.003 * uParticleAnim;

  // Start below ground, travel to target elevation
  float startElev   = max(0.0, elevation - 0.05);
  float currentElev = mix(startElev, elevation, mix(1.0, smoothT, uParticleAnim));

  // ── 2. Compute world position ───────────────────────────────────────────────
  float r      = uGlobeRadius + currentElev * uElevationScale * 0.12 + wobble;
  vec3  pos    = direction * r;

  // ── 3. Color by elevation + blend slider ────────────────────────────────────
  //  Low elevation → water color, high → land color, blended by slider
  vec3  elevColor  = mix(uWaterColor, uLandColor, elevation * uColorBlend);
  //  Rivers (land=0) get water color directly
  vColor           = mix(uWaterColor * 0.7, elevColor, land);
  vElevation       = elevation;
  vLand            = land;

  // ── 4. Fade out at low elevations (tutorial's mask effect) ─────────────────
  vOpacity = smoothstep(0.0, 0.08, elevation) * mix(1.0, smoothT, uParticleAnim * 0.4);

  // ── 5. Point size — larger at high elevation, smaller at sea level ──────────
  //  Perspective divide handled automatically by gl_PointSize
  float sizeMod = 1.0 + elevation * 1.2;
  gl_PointSize  = uPointSize * sizeMod;

  gl_Position   = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}
