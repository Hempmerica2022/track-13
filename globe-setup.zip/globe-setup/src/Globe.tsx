// =============================================================================
//  Globe.tsx — 3D Point Cloud Globe
//  Uses universal GLSL ShaderMaterial (WebGL 1/2 — all browsers/devices)
// =============================================================================

import { useRef, useMemo, useEffect, useState } from 'react'
import { useFrame, useThree, invalidate } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import { useGlobeStore } from './globeStore'
import { usePointCloudMaterial, useAtmosphereMaterial } from './useGlobeShader'

// ── Types ─────────────────────────────────────────────────────────────────────
interface GlobePoint {
  lat: number
  lon: number
  elevation: number
  land: 0 | 1
}

const DEG2RAD     = Math.PI / 180
const GLOBE_RADIUS = 1.0

// ── Lat/Lon → unit sphere direction ───────────────────────────────────────────
function latLonToDir(lat: number, lon: number): [number, number, number] {
  const phi   = (90 - lat)  * DEG2RAD
  const theta = (lon + 180) * DEG2RAD
  return [
    -Math.sin(phi) * Math.cos(theta),
     Math.cos(phi),
     Math.sin(phi) * Math.sin(theta),
  ]
}

// =============================================================================
//  Point Cloud Geometry — built once from globe.json
// =============================================================================
function useGlobeGeometry() {
  const [geometry, setGeometry] = useState<THREE.BufferGeometry | null>(null)
  const [loading,  setLoading ] = useState(true)
  const [error,    setError   ] = useState<string | null>(null)

  useEffect(() => {
    fetch('/global-vision/data/globe.json')
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status} — globe.json not found`)
        return r.json() as Promise<GlobePoint[]>
      })
      .then(points => {
        const count = points.length

        const directions  = new Float32Array(count * 3)
        const elevations  = new Float32Array(count)
        const lands       = new Float32Array(count)

        points.forEach((p, i) => {
          const [dx, dy, dz] = latLonToDir(p.lat, p.lon)
          directions[i * 3]     = dx
          directions[i * 3 + 1] = dy
          directions[i * 3 + 2] = dz
          elevations[i]         = p.elevation
          lands[i]              = p.land
        })

        const geo = new THREE.BufferGeometry()
        geo.setAttribute('direction', new THREE.BufferAttribute(directions, 3))
        geo.setAttribute('elevation', new THREE.BufferAttribute(elevations,  1))
        geo.setAttribute('land',      new THREE.BufferAttribute(lands,       1))

        // Dummy position attribute (required by Three.js, actual pos set in vertex shader)
        geo.setAttribute('position',  new THREE.BufferAttribute(new Float32Array(count * 3), 3))

        setGeometry(geo)
        setLoading(false)
        invalidate()
        console.log(`[Globe] Loaded ${count.toLocaleString()} points`)
      })
      .catch(err => {
        setError(err.message)
        setLoading(false)
        console.warn('[Globe] globe.json not found — showing placeholder sphere')
      })
  }, [])

  return { geometry, loading, error }
}

// =============================================================================
//  Globe Component
// =============================================================================
export function Globe() {
  const {
    spinEnabled, sphereOpacity, waterColor,
    lightColor, lightIntensity,
  } = useGlobeStore()

  const { camera }   = useThree()
  const groupRef     = useRef<THREE.Group>(null)
  const pointsMat    = usePointCloudMaterial()
  const atmosphereMat = useAtmosphereMaterial()
  const { geometry, loading, error } = useGlobeGeometry()

  // ── Spin: move camera around stationary globe (tutorial approach) ──────────
  useFrame((_state, delta) => {
    if (spinEnabled) {
      camera.position.applyAxisAngle(new THREE.Vector3(0, 1, 0), delta * 0.08)
      camera.lookAt(0, 0, 0)
      invalidate()
    }
  })

  // ── Base sphere material ───────────────────────────────────────────────────
  const sphereMat = useMemo(() => new THREE.MeshStandardMaterial({
    color:       waterColor,
    transparent: true,
    opacity:     sphereOpacity,
    roughness:   0.9,
    metalness:   0.05,
  }), [waterColor, sphereOpacity])

  return (
    <group ref={groupRef}>

      {/* ── Lighting: ambient + rim sun + backlight (tutorial spec) ─────── */}
      <ambientLight intensity={0.25} />

      {/* Sun — stationary rim light from the Pacific side */}
      <directionalLight
        position={[4, 1, 2]}
        color={lightColor}
        intensity={lightIntensity}
      />

      {/* Backlight — parented to scene origin, cool blue fill */}
      <directionalLight
        position={[0, -2, -3]}
        color="#2255aa"
        intensity={0.35}
      />

      {/* ── Atmosphere halo (Fresnel rim glow) ──────────────────────────── */}
      <mesh scale={[1.12, 1.12, 1.12]}>
        <sphereGeometry args={[GLOBE_RADIUS, 64, 64]} />
        <primitive object={atmosphereMat} attach="material" />
      </mesh>

      {/* ── Base water sphere ────────────────────────────────────────────── */}
      <mesh>
        <sphereGeometry args={[GLOBE_RADIUS * 0.994, 64, 64]} />
        <primitive object={sphereMat} attach="material" />
      </mesh>

      {/* ── Point cloud — only renders when globe.json is loaded ────────── */}
      {geometry && (
        <points geometry={geometry}>
          <primitive object={pointsMat} attach="material" />
        </points>
      )}

      {/* ── Loading / error state placeholder ───────────────────────────── */}
      {loading && (
        <mesh>
          <sphereGeometry args={[GLOBE_RADIUS * 1.001, 32, 32]} />
          <meshBasicMaterial color="#1a3a5c" wireframe opacity={0.15} transparent />
        </mesh>
      )}

      {/* ── Orbit controls ───────────────────────────────────────────────── */}
      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={1.4}
        maxDistance={5}
        onChange={() => invalidate()}
      />

    </group>
  )
}
