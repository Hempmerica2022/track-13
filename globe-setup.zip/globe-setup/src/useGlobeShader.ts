// =============================================================================
//  useGlobeShader.ts
//  Loads GLSL shaders and keeps uniforms in sync with Zustand store + time
//  Cross-platform: pure WebGL ShaderMaterial — no WebGPU required
// =============================================================================

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useGlobeStore } from './globeStore'

// Vite raw import — shader strings bundled at build time (zero runtime fetch)
import vertGlsl from './shaders/globe.vert.glsl?raw'
import fragGlsl from './shaders/globe.frag.glsl?raw'
import atmosVert from './shaders/atmosphere.vert.glsl?raw'
import atmosFrag from './shaders/atmosphere.frag.glsl?raw'

// ── Helper: hex string → THREE.Color ─────────────────────────────────────────
const hex = (h: string) => new THREE.Color(h)

// =============================================================================
//  Point Cloud ShaderMaterial
// =============================================================================
export function usePointCloudMaterial() {
  const store = useGlobeStore()
  const matRef = useRef<THREE.ShaderMaterial | null>(null)

  const material = useMemo(() => {
    const mat = new THREE.ShaderMaterial({
      vertexShader:   vertGlsl,
      fragmentShader: fragGlsl,
      transparent:    true,
      depthWrite:     false,       // prevents z-fighting with sphere
      blending:       THREE.AdditiveBlending, // bright additive glow

      uniforms: {
        uTime:           { value: 0 },
        uElevationScale: { value: store.elevationScale },
        uGlobeRadius:    { value: 1.0 },
        uPointSize:      { value: 2.5 },
        uColorBlend:     { value: store.colorBlend },
        uLandColor:      { value: hex(store.landColor) },
        uWaterColor:     { value: hex(store.waterColor) },
        uParticleAnim:   { value: store.particleAnim ? 1.0 : 0.0 },
        uAnimSpeed:      { value: 0.25 },
        uGlowAmount:     { value: store.glowAmount },
        uGlowThreshold:  { value: store.glowThreshold },
      },
    })

    matRef.current = mat
    return mat
  }, []) // created once

  // ── Sync uniforms every frame (cheap — just setting float/vec3 values) ──────
  useFrame(({ clock }) => {
    const mat = matRef.current
    if (!mat) return

    const s = useGlobeStore.getState()

    mat.uniforms.uTime.value           = clock.getElapsedTime()
    mat.uniforms.uElevationScale.value = s.elevationScale
    mat.uniforms.uColorBlend.value     = s.colorBlend
    mat.uniforms.uParticleAnim.value   = s.particleAnim ? 1.0 : 0.0
    mat.uniforms.uGlowAmount.value     = s.glowAmount
    mat.uniforms.uGlowThreshold.value  = s.glowThreshold

    // Only create new THREE.Color when value actually changed
    ;(mat.uniforms.uLandColor.value  as THREE.Color).set(s.landColor)
    ;(mat.uniforms.uWaterColor.value as THREE.Color).set(s.waterColor)
  })

  return material
}

// =============================================================================
//  Atmosphere ShaderMaterial
// =============================================================================
export function useAtmosphereMaterial() {
  const material = useMemo(() => new THREE.ShaderMaterial({
    vertexShader:   atmosVert,
    fragmentShader: atmosFrag,
    transparent:    true,
    depthWrite:     false,
    side:           THREE.BackSide,  // render inside-out for the halo effect
    blending:       THREE.AdditiveBlending,

    uniforms: {
      uAtmosColor:    { value: new THREE.Color('#3a7bd5') },
      uAtmosStrength: { value: 1.2 },
    },
  }), [])

  return material
}
